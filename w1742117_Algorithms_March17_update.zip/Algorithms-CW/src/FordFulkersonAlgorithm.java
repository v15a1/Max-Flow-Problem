//UOW Student ID - w1742117
//IIT Student ID - 2018418
//NAME = VISAL RAJAPAKSE

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FordFulkersonAlgorithm extends Solver {

    //constructor
    public FordFulkersonAlgorithm(int n, int s, int t) {
        super(n, s, t);
    }

    @Override
    //overridden solve() method to execute when the getMaxFlow() method is invoked
    public void solve() {
        for (double flow = depthFirstSearch(s, MAX_VALUE); flow != 0; flow = depthFirstSearch(s, MAX_VALUE)) {
            visitedToken++;
            maxFlow += flow;     //adding the received flow to the maximum flow
        }
    }

    @Override
    //overridden method to print out all the edges of the final graph with no more augmenting paths
    public void printFinalGraphEdges(List<Edge>[] graph) {
        for (int x = 0; x < n; x++) {
            List<Edge> edges = graph[x];
            for (Edge edge : edges) {
                if (edge.flow > 0) {
                    System.out.println(edge);
                }
            }
        }
    }

    //method that executes depth first search on the graph
    private double depthFirstSearch(int currentVertex, double flow) {
        if (currentVertex == t) {
            return flow;
        }
        //setting the current vertex to visited to prevent cycling
        visited[currentVertex] = visitedToken;

        //getting an array list from the array of arraylists as paths
        List<Edge> edges = graph[currentVertex];
        for (Edge edge : edges) {
            if (edge.residualCapacity() > 0 && visited[edge.to] != visitedToken) {
                //finding the bottleneck capacity by recursively invoking DFS
                double bottleneck = depthFirstSearch(edge.to, Math.min(flow, edge.residualCapacity()));
                if (bottleneck > 0) {
                    edge.augment(bottleneck);
                    return bottleneck;
                }
            }
        }
        return 0;
    }

}
