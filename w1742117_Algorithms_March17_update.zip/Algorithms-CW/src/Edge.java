//UOW Student ID - w1742117
//IIT Student ID - 2018418
//NAME = VISAL RAJAPAKSE

public class Edge {
    public int from;        //integer value of start of an edge
    public int to;          //integer value of end of an edge
    public Edge residualEdge;       //residual edge of the edge
    public double flow;
    public final double capacity;

    //constructor to initialize instance variables
    public Edge(int from, int to,  double capacity) {
        this.from = from;
        this.to = to;
        this.capacity = capacity;
    }

    //method to find the residual capacity
    public double residualCapacity(){
        return capacity - flow;
    }

    public void augment(double bottleneck){
        flow += bottleneck;
        residualEdge.flow -= bottleneck;
    }

    @Override
    public String toString() {
        return "Edge{" +
                "from=" + from +
                ", to=" + to +
                ", flow=" + flow +
                ", capacity=" + capacity +
                '}';
    }
}
