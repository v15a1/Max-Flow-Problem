//UOW Student ID - w1742117
//IIT Student ID - 2018418
//NAME = VISAL RAJAPAKSE

import java.util.ArrayList;
import java.util.List;

public abstract class Solver {

    static final double MAX_VALUE = Double.POSITIVE_INFINITY;

    //having protected values to allow inherited classes access the variables
    int n;
    int s;
    int t;
    int visitedToken = 1;
    int[] visited;
    double maxFlow;
    static List<Edge>[] graph;

    private boolean isSolved;

    //constructor to initialize the values
    public Solver(int n, int s, int t) {
        this.n = n;
        this.s = s;
        this.t = t;

        //initializing an array of lists to hold values of each edge
        graph = new List[n];
        for (int x = 0; x < n; x++) {
            graph[x] = new ArrayList<>();
        }
        //array to prevent cyling of the depth first search
        visited = new int[n];
    }

    //method to add an edge to the graph
    public void addEdgeToGraph(int from, int to, double capacity) {
        Edge e1 = new Edge(from, to, capacity);
        Edge e2 = new Edge(to, from, 0);        //reverse flow

        //assigning residual edges
        e1.residualEdge = e2;
        e2.residualEdge = e1;
        //adding edges to the graph
        graph[from].add(e1);
        graph[to].add(e2);
    }

    //method that invokes overridden solve method in the FordFulkersonAlgorithm class
    public double getMaxFlow() {
        execute();
        return maxFlow;
    }

    //method to execute the algorithm
    public void execute() {
        if (isSolved) {
            return;
        }
        isSolved = true;
        solve();
    }

    public abstract void solve();

    public abstract void printFinalGraphEdges(List<Edge>[] graph);
}
