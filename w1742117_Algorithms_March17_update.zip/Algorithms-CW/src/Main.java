//UOW Student ID - w1742117
//IIT Student ID - 2018418
//NAME = VISAL RAJAPAKSE

public class Main {
    //https://www.youtube.com/watch?v=Xu8jjJnwvxE
    public static void main(String[] args) {
        //declaring the number of nodes, the source node and sink node
        int n = 6;
        int s = 0;
        int t = 5;

        Solver solver = new FordFulkersonAlgorithm(n, s, t);

//        //youtube solution graph
//        solver.addEdgeToGraph(s, 1, 10);
//        solver.addEdgeToGraph(s, 2, 10);
//
//        solver.addEdgeToGraph(1, 2, 2);
//        solver.addEdgeToGraph(1, 4, 8);
//        solver.addEdgeToGraph(1, 3, 4);
//        solver.addEdgeToGraph(2, 4, 9);
//        solver.addEdgeToGraph(4, 3, 6);
//
//        solver.addEdgeToGraph(3, t, 10);
//        solver.addEdgeToGraph(4, t, 10);

//        //cw spec sheet graph
//        solver.addEdgeToGraph(s, 1, 10);
//        solver.addEdgeToGraph(s, 2, 8);
//
//        solver.addEdgeToGraph(1, 2, 5);
//        solver.addEdgeToGraph(1, 3, 5);
//        solver.addEdgeToGraph(2, 1, 4);
//        solver.addEdgeToGraph(2, 4, 10);
//        solver.addEdgeToGraph(3, 2, 7);
//        solver.addEdgeToGraph(3, 4, 6);
//        solver.addEdgeToGraph(4, 3, 10);
//
//        solver.addEdgeToGraph(3, t, 3);
//        solver.addEdgeToGraph(4, t, 14);

        //geeks for geeks graph
        solver.addEdgeToGraph(s, 1, 16);
        solver.addEdgeToGraph(s, 2,  13);

        solver.addEdgeToGraph(1, 2, 10);
        solver.addEdgeToGraph(1, 3, 12);
        solver.addEdgeToGraph(2, 1, 4);
        solver.addEdgeToGraph(2, 4, 14);
        solver.addEdgeToGraph(3, 2, 9);
        solver.addEdgeToGraph(4, 3, 7);

        solver.addEdgeToGraph(3, t, 20);
        solver.addEdgeToGraph(4, t, 4);

        System.out.println("The maximum flow for the given graph is "+solver.getMaxFlow());
        System.out.println("The final edges and their respective values are...");
        solver.printFinalGraphEdges(Solver.graph);

    }
}
